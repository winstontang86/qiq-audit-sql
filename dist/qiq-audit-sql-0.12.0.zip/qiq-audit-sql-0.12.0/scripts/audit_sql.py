#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
qiq-audit-sql: DB 规范自动检查脚本

用法:
    python audit_sql.py <path> [path...] [--strict] [--format md|json] [-o out.md]

支持:
    - .sql 文件
    - 源码文件（.go/.py/.js/.ts/.java/.kt/.rs/.cpp/.c/.cc/.h/.php/.rb/.scala）
      会从字符串字面量中提取嵌入 SQL（识别含 CREATE/ALTER/SELECT/INSERT/UPDATE/DELETE 关键字的字符串）

输出:
    Markdown 格式的违规报告（默认 stdout，或 -o 输出到文件）。

退出码:
    0 = 通过（无 MUST 违规；--strict 模式下要求无任何违规）
    1 = 存在 MUST 违规（或 --strict 模式下存在任何违规）
    2 = 输入参数错误

豁免与项目配置:
    - 内联豁免注释（仅识别 SQL 注释里的标记）：
        -- audit-sql:disable-file=1.2.1,1.1.20  reason=upstream keycloak schema
        /* audit-sql:disable-file=* reason=test fixture */
        -- audit-sql:disable-next-line=1.2.1 reason=月分表占位符
        CREATE TABLE t_log_YYYYMM (...);
      支持具体规则号、英文逗号分隔多个规则号、`*` 表示全部规则。
    - 项目级配置：仓库根目录 `.audit-sql.json`，首版字段：
        {
          "column_aliases": {
            "create_at": ["created_at", "gmt_create"],
            "update_at": ["updated_at", "gmt_modified"]
          },
          "table_name_placeholders": ["_YYYYMM", "_YYYYMMDD"],
          "excluded_paths": ["**/keycloak-bridge/**", "**/test/fixture/**"]
        }
"""

from __future__ import annotations

import argparse
import fnmatch
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

# skill 工作文件目录（落在被检查仓库根下）
WORKDIR_NAME = os.path.join(".qiqskills", "audit-sql")

# 项目级配置文件名（位于被检查仓库根目录）
CONFIG_FILE_NAME = ".audit-sql.json"

# 1.1.19 必备语义字段的内置命名族（可被项目配置 column_aliases 扩展）
# key = 规范中的标准字段名；value = 与之等价的别名集合
DEFAULT_COLUMN_ALIASES: dict[str, list[str]] = {
    "id": [],
    "create_at": ["created_at", "gmt_create", "ctime"],
    "update_at": ["updated_at", "gmt_modified", "mtime"],
}

# 路径关键字 → 报告分组提示。命中即把该文件下的 findings 归入「上游/历史兼容」。
# 这是启发式判定，仅用于报告分档；不会改变规则判定本身。
UPSTREAM_PATH_HINTS = (
    "keycloak", "temporal", "gitlab", "camunda", "airflow",
    "mock-llm", "mock_llm",
)

# 同样用于报告分档的「测试/fixture」路径启发式。
TEST_FIXTURE_PATH_HINTS = (
    "/test/", "/tests/", "/fixture/", "/fixtures/", "/__test__/",
)

# -------------------- 数据结构 --------------------

LEVEL_MUST = "MUST"
LEVEL_RECOMMEND = "RECOMMEND"


@dataclass
class Finding:
    rule_id: str
    level: str  # MUST / RECOMMEND
    title: str
    message: str
    file: str
    line: int = 0
    snippet: str = ""

    def to_dict(self):
        return {
            "rule_id": self.rule_id,
            "level": self.level,
            "title": self.title,
            "message": self.message,
            "file": self.file,
            "line": self.line,
            "snippet": self.snippet,
        }


@dataclass
class SqlBlock:
    """从源文件中提取出的一条/一段 SQL 内容。"""
    text: str
    file: str
    start_line: int  # 原始文件中的起始行号

    def line_of_offset(self, offset: int) -> int:
        return self.start_line + self.text[:offset].count("\n")


@dataclass
class ProjectConfig:
    """项目级配置（来自 .audit-sql.json，可缺省）。"""
    # {标准字段名 → 等价别名集合}，已合并默认值
    column_aliases: dict[str, set[str]] = field(default_factory=dict)
    # 表名占位符片段（命中时跳过 1.2.1 命名检查），如 "_YYYYMM"
    table_name_placeholders: list[str] = field(default_factory=list)
    # 路径 glob，命中视为「上游/历史兼容」，**不豁免**，只用于报告分档
    excluded_paths: list[str] = field(default_factory=list)
    # 配置文件来源路径（None = 未找到，使用默认）
    source_path: str | None = None

    def required_field_aliases(self, std_name: str) -> set[str]:
        """返回某个必备字段（如 create_at）所有可接受的命名（含自身）。"""
        names = {std_name.lower()}
        names.update(a.lower() for a in self.column_aliases.get(std_name, set()))
        return names

    def is_placeholder_table(self, name: str) -> bool:
        for ph in self.table_name_placeholders:
            if not ph:
                continue
            if ph in name:
                return True
        return False

    def is_excluded(self, file_path: str) -> bool:
        if not self.excluded_paths:
            return False
        norm = file_path.replace("\\", "/")
        for pat in self.excluded_paths:
            if fnmatch.fnmatch(norm, pat):
                return True
            # 兼容仅给目录前缀的写法
            if fnmatch.fnmatch(norm, f"*{pat}*"):
                return True
        return False


def load_project_config(start_paths: list[str]) -> ProjectConfig:
    """
    从被检查路径向上查找 `.audit-sql.json`：
    1) 优先用 git 仓库根；
    2) 没有 git 时，用第一个路径所在目录向上找直到根。
    找不到时返回包含默认值的 ProjectConfig。
    """
    cfg = ProjectConfig()
    # 先把内置默认 alias 灌进去（用 set，便于后续 union）
    for k, v in DEFAULT_COLUMN_ALIASES.items():
        cfg.column_aliases[k] = set(x.lower() for x in v)

    cfg_path: Path | None = None
    if start_paths:
        anchor = Path(start_paths[0]).resolve()
        if anchor.is_file():
            anchor = anchor.parent
        # 1) 试 git root
        try:
            out = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                cwd=str(anchor),
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            root = Path(out.stdout.strip())
            candidate = root / CONFIG_FILE_NAME
            if candidate.is_file():
                cfg_path = candidate
        except (FileNotFoundError, subprocess.CalledProcessError):
            pass
        # 2) 向上找
        if cfg_path is None:
            cur = anchor
            while True:
                candidate = cur / CONFIG_FILE_NAME
                if candidate.is_file():
                    cfg_path = candidate
                    break
                if cur.parent == cur:
                    break
                cur = cur.parent

    if cfg_path is None:
        return cfg

    try:
        raw = json.loads(cfg_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"[audit-sql] 警告：无法解析配置 {cfg_path}: {e}", file=sys.stderr)
        return cfg

    cfg.source_path = str(cfg_path)
    # column_aliases：与默认合并
    aliases = raw.get("column_aliases") or {}
    if isinstance(aliases, dict):
        for std_name, alts in aliases.items():
            if not isinstance(alts, list):
                continue
            cfg.column_aliases.setdefault(std_name, set()).update(
                a.lower() for a in alts if isinstance(a, str)
            )
    # table_name_placeholders
    phs = raw.get("table_name_placeholders") or []
    if isinstance(phs, list):
        cfg.table_name_placeholders = [p for p in phs if isinstance(p, str) and p]
    # excluded_paths
    exps = raw.get("excluded_paths") or []
    if isinstance(exps, list):
        cfg.excluded_paths = [p for p in exps if isinstance(p, str) and p]
    return cfg


# -------------------- 内联豁免（建议 1） --------------------

# 仅识别 SQL 注释里的豁免标记。形态示例：
#   -- audit-sql:disable-file=1.2.1,1.1.20 reason=xxx
#   /* audit-sql:disable-file=* */
#   -- audit-sql:disable-next-line=1.2.1
RE_DISABLE_DIRECTIVE = re.compile(
    r"audit-sql:(disable-file|disable-next-line)\s*=\s*([\w\.\*,\s]+)",
    re.IGNORECASE,
)


@dataclass
class FileExemptions:
    """针对单个源文件汇总后的豁免规则（按真实文件行号）。"""
    file_disabled: set[str] = field(default_factory=set)        # "*" 或 具体规则号
    line_disabled: dict[int, set[str]] = field(default_factory=dict)  # 行号 → {规则号}

    def covers(self, rule_id: str, line: int) -> bool:
        if "*" in self.file_disabled or rule_id in self.file_disabled:
            return True
        rules = self.line_disabled.get(line)
        if rules and ("*" in rules or rule_id in rules):
            return True
        return False


def _parse_disable_rules(raw: str) -> set[str]:
    items = set()
    for tok in re.split(r"[,\s]+", raw.strip()):
        if not tok:
            continue
        if tok == "*":
            items.add("*")
            continue
        # 只接受形如 1.2.1 / 2.10 这种规则号；忽略 reason= 等无关 token
        if re.match(r"^\d+(?:\.\d+){1,3}$", tok):
            items.add(tok)
    return items


def collect_exemptions(text: str, file: str) -> FileExemptions:
    """
    扫描整个源文件文本（.sql 或宿主语言文件均可），
    抓取 SQL 风格注释里的豁免指令。

    实现策略：直接正则匹配 `-- ...` 与 `/* ... */` 中的 `audit-sql:` 指令。
    在宿主语言里，宿主自身的注释（如 Go `// ...`）不会被识别——这是有意为之。
    """
    ex = FileExemptions()

    # 1) -- 单行注释
    for m in re.finditer(r"--[^\n]*", text):
        seg = m.group(0)
        line_no = text.count("\n", 0, m.start()) + 1
        for d in RE_DISABLE_DIRECTIVE.finditer(seg):
            kind = d.group(1).lower()
            rules = _parse_disable_rules(d.group(2))
            if not rules:
                continue
            if kind == "disable-file":
                ex.file_disabled.update(rules)
            else:  # disable-next-line
                # 「下一行」= 当前注释所在行的 +1（按文件原始行号）
                target = line_no + 1
                ex.line_disabled.setdefault(target, set()).update(rules)

    # 2) /* ... */ 多行注释（跨行支持）
    for m in re.finditer(r"/\*.*?\*/", text, re.DOTALL):
        seg = m.group(0)
        start_line = text.count("\n", 0, m.start()) + 1
        end_line = start_line + seg.count("\n")
        for d in RE_DISABLE_DIRECTIVE.finditer(seg):
            kind = d.group(1).lower()
            rules = _parse_disable_rules(d.group(2))
            if not rules:
                continue
            if kind == "disable-file":
                ex.file_disabled.update(rules)
            else:
                # 「下一行」= 注释结束行 +1
                target = end_line + 1
                ex.line_disabled.setdefault(target, set()).update(rules)

    return ex


# -------------------- 保留字（精简集，覆盖最常见） --------------------
# 来源：MySQL 8.0 reserved words 主要集合 + 常见关键字。完整集太大，列高频。
RESERVED_WORDS = {
    "accessible", "add", "all", "alter", "analyze", "and", "as", "asc", "asensitive",
    "before", "between", "bigint", "binary", "blob", "both", "by",
    "call", "cascade", "case", "change", "char", "character", "check", "collate",
    "column", "condition", "constraint", "continue", "convert", "create", "cross",
    "cube", "cume_dist", "current_date", "current_time", "current_timestamp", "current_user",
    "cursor",
    "database", "databases", "day_hour", "day_microsecond", "day_minute", "day_second",
    "dec", "decimal", "declare", "default", "delayed", "delete", "dense_rank", "desc",
    "describe", "deterministic", "distinct", "distinctrow", "div", "double", "drop", "dual",
    "each", "else", "elseif", "empty", "enclosed", "escaped", "except", "exists", "exit",
    "explain",
    "false", "fetch", "first_value", "float", "float4", "float8", "for", "force", "foreign",
    "from", "fulltext", "function",
    "generated", "get", "grant", "group", "grouping", "groups",
    "having", "high_priority", "hour_microsecond", "hour_minute", "hour_second",
    "if", "ignore", "in", "index", "infile", "inner", "inout", "insensitive", "insert",
    "int", "int1", "int2", "int3", "int4", "int8", "integer", "intersect", "interval", "into",
    "io_after_gtids", "io_before_gtids", "is", "iterate",
    "join", "json_table",
    "key", "keys", "kill",
    "lag", "last_value", "lateral", "lead", "leading", "leave", "left", "like", "limit",
    "linear", "lines", "load", "localtime", "localtimestamp", "lock", "long", "longblob",
    "longtext", "loop", "low_priority",
    "master_bind", "master_ssl_verify_server_cert", "match", "maxvalue", "mediumblob",
    "mediumint", "mediumtext", "middleint", "minute_microsecond", "minute_second", "mod",
    "modifies",
    "natural", "not", "no_write_to_binlog", "nth_value", "ntile", "null", "numeric",
    "of", "on", "optimize", "optimizer_costs", "option", "optionally", "or", "order", "out",
    "outer", "outfile", "over",
    "partition", "percent_rank", "precision", "primary", "procedure", "purge",
    "range", "rank", "read", "reads", "read_write", "real", "recursive", "references",
    "regexp", "release", "rename", "repeat", "replace", "require", "resignal", "restrict",
    "return", "revoke", "right", "rlike", "row", "rows", "row_number",
    "schema", "schemas", "second_microsecond", "select", "sensitive", "separator", "set",
    "show", "signal", "smallint", "spatial", "specific", "sql", "sqlexception", "sqlstate",
    "sqlwarning", "sql_big_result", "sql_calc_found_rows", "sql_small_result", "ssl",
    "starting", "stored", "straight_join", "system",
    "table", "tables", "terminated", "then", "tinyblob", "tinyint", "tinytext", "to",
    "trailing", "trigger", "true",
    "undo", "union", "unique", "unlock", "unsigned", "update", "usage", "use", "using",
    "utc_date", "utc_time", "utc_timestamp",
    "values", "varbinary", "varchar", "varcharacter", "varying", "virtual",
    "when", "where", "while", "window", "with", "write",
    "xor",
    "year_month",
    "zerofill",
}

# -------------------- 工具函数 --------------------

SOURCE_EXTS = {
    ".go", ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".kt", ".rs",
    ".cpp", ".cc", ".cxx", ".c", ".h", ".hpp", ".php", ".rb", ".scala",
}

SQL_KEYWORDS_FOR_DETECT = re.compile(
    r"\b(SELECT|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP|TRUNCATE|REPLACE|CALL)\b",
    re.IGNORECASE,
)


def strip_sql_comments(sql: str) -> str:
    """删除 SQL 注释：-- ... 单行、/* */ 多行、# 单行（hash 注释）。
    保留长度，便于行号计算 → 改用占位空格替换。
    """
    out = []
    i = 0
    n = len(sql)
    while i < n:
        ch = sql[i]
        nxt = sql[i + 1] if i + 1 < n else ""
        # 单引号字符串
        if ch == "'":
            j = i + 1
            while j < n:
                if sql[j] == "\\" and j + 1 < n:
                    j += 2
                    continue
                if sql[j] == "'":
                    if j + 1 < n and sql[j + 1] == "'":  # 连续两个单引号转义
                        j += 2
                        continue
                    j += 1
                    break
                j += 1
            out.append(sql[i:j])
            i = j
            continue
        # 双引号字符串
        if ch == '"':
            j = i + 1
            while j < n:
                if sql[j] == "\\" and j + 1 < n:
                    j += 2
                    continue
                if sql[j] == '"':
                    j += 1
                    break
                j += 1
            out.append(sql[i:j])
            i = j
            continue
        # 反引号标识符
        if ch == "`":
            j = i + 1
            while j < n and sql[j] != "`":
                j += 1
            j = min(j + 1, n)
            out.append(sql[i:j])
            i = j
            continue
        # /* */ 注释
        if ch == "/" and nxt == "*":
            j = sql.find("*/", i + 2)
            if j == -1:
                j = n
            else:
                j += 2
            # 保留换行
            out.append("".join("\n" if c == "\n" else " " for c in sql[i:j]))
            i = j
            continue
        # -- 单行注释
        if ch == "-" and nxt == "-":
            j = sql.find("\n", i)
            if j == -1:
                j = n
            out.append(" " * (j - i))
            i = j
            continue
        # # 单行注释（MySQL 支持）
        if ch == "#":
            j = sql.find("\n", i)
            if j == -1:
                j = n
            out.append(" " * (j - i))
            i = j
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def split_statements(sql: str) -> list[tuple[int, str]]:
    """按分号拆分语句，跳过字符串内的分号。返回 [(offset, statement_text), ...]。"""
    stmts: list[tuple[int, str]] = []
    n = len(sql)
    i = 0
    start = 0
    while i < n:
        ch = sql[i]
        if ch in ("'", '"'):
            quote = ch
            j = i + 1
            while j < n:
                if sql[j] == "\\" and j + 1 < n:
                    j += 2
                    continue
                if sql[j] == quote:
                    if j + 1 < n and sql[j + 1] == quote:
                        j += 2
                        continue
                    j += 1
                    break
                j += 1
            i = j
            continue
        if ch == "`":
            j = i + 1
            while j < n and sql[j] != "`":
                j += 1
            i = min(j + 1, n)
            continue
        if ch == ";":
            stmt = sql[start:i].strip()
            if stmt:
                stmts.append((start, stmt))
            i += 1
            start = i
            continue
        i += 1
    tail = sql[start:].strip()
    if tail:
        stmts.append((start, tail))
    return stmts


def extract_sql_blocks_from_source(src: str, file: str) -> list[SqlBlock]:
    """从源代码字符串字面量中提取可能的 SQL 块。"""
    blocks: list[SqlBlock] = []
    n = len(src)
    i = 0
    while i < n:
        ch = src[i]
        # 反引号（Go/JS template / 多行字符串）
        if ch == "`":
            j = i + 1
            while j < n and src[j] != "`":
                j += 1
            content = src[i + 1: j]
            if SQL_KEYWORDS_FOR_DETECT.search(content):
                start_line = src[:i].count("\n") + 1
                blocks.append(SqlBlock(content, file, start_line))
            i = j + 1
            continue
        # 三引号字符串（Python/Scala）
        if ch in ('"', "'") and src[i:i + 3] in ('"""', "'''"):
            quote = src[i:i + 3]
            j = src.find(quote, i + 3)
            if j == -1:
                j = n
            content = src[i + 3: j]
            if SQL_KEYWORDS_FOR_DETECT.search(content):
                start_line = src[:i].count("\n") + 1
                blocks.append(SqlBlock(content, file, start_line))
            i = j + 3
            continue
        # 单/双引号字符串
        if ch in ('"', "'"):
            quote = ch
            j = i + 1
            while j < n:
                if src[j] == "\\" and j + 1 < n:
                    j += 2
                    continue
                if src[j] == quote:
                    break
                if src[j] == "\n":
                    # 大多数语言单/双引号不允许换行，遇到换行就放弃
                    break
                j += 1
            content = src[i + 1: j]
            if SQL_KEYWORDS_FOR_DETECT.search(content):
                start_line = src[:i].count("\n") + 1
                blocks.append(SqlBlock(content, file, start_line))
            i = j + 1
            continue
        i += 1
    return blocks


# -------------------- 检查器 --------------------

# CREATE TABLE 的整体匹配
RE_CREATE_TABLE = re.compile(
    r"\bCREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?[`\"]?(\w+)[`\"]?\s*\((.*?)\)\s*(ENGINE\s*=\s*\w+|DEFAULT\s+CHARSET|CHARACTER\s+SET|/\*.*?\*/|;|$)?",
    re.IGNORECASE | re.DOTALL,
)

RE_CREATE_DATABASE = re.compile(
    r"\bCREATE\s+(?:DATABASE|SCHEMA)\s+(?:IF\s+NOT\s+EXISTS\s+)?[`\"]?(\w+)[`\"]?(.*?)(?:;|$)",
    re.IGNORECASE | re.DOTALL,
)


def _strip_inline_parens(s: str) -> str:
    """把 column 行内的小括号(如 varchar(64)、decimal(10,2))内容去掉，便于按逗号拆列。"""
    out = []
    depth = 0
    for c in s:
        if c == "(":
            depth += 1
            continue
        if c == ")":
            depth = max(depth - 1, 0)
            continue
        if depth == 0:
            out.append(c)
    return "".join(out)


def split_columns_block(body: str) -> list[str]:
    """把 CREATE TABLE 括号内的体按顶层逗号拆开。"""
    items: list[str] = []
    depth = 0
    cur = []
    in_q = None
    i = 0
    n = len(body)
    while i < n:
        ch = body[i]
        if in_q:
            cur.append(ch)
            if ch == "\\" and i + 1 < n:
                cur.append(body[i + 1])
                i += 2
                continue
            if ch == in_q:
                in_q = None
            i += 1
            continue
        if ch in ("'", '"', "`"):
            in_q = ch
            cur.append(ch)
            i += 1
            continue
        if ch == "(":
            depth += 1
            cur.append(ch)
            i += 1
            continue
        if ch == ")":
            depth -= 1
            cur.append(ch)
            i += 1
            continue
        if ch == "," and depth == 0:
            items.append("".join(cur).strip())
            cur = []
            i += 1
            continue
        cur.append(ch)
        i += 1
    if cur:
        item = "".join(cur).strip()
        if item:
            items.append(item)
    return items


# -------------------- 各项检查实现 --------------------

class Auditor:
    def __init__(self, config: ProjectConfig | None = None):
        self.findings: list[Finding] = []
        self.config: ProjectConfig = config or ProjectConfig()

    def add(self, f: Finding):
        self.findings.append(f)

    # === 入口 ===
    def audit_block(self, block: SqlBlock):
        cleaned = strip_sql_comments(block.text)
        for stmt_offset, stmt in split_statements(cleaned):
            # 跳过语句前的空白/换行，拿「语句首个非空字符」对应的行号作为语句起始行。
            real_offset = stmt_offset
            while real_offset < len(cleaned) and cleaned[real_offset] in (" ", "\t", "\r", "\n"):
                real_offset += 1
            line = block.line_of_offset(real_offset)
            self._audit_statement(stmt, block.file, line)

    def _audit_statement(self, stmt: str, file: str, line: int):
        s = stmt.strip()
        upper_head = s.upper().lstrip("(").lstrip()
        # 分类
        if re.match(r"CREATE\s+(DATABASE|SCHEMA)\b", upper_head):
            self._check_create_database(s, file, line)
        elif re.match(r"CREATE\s+TABLE\b", upper_head):
            self._check_create_table(s, file, line)
        elif re.match(r"ALTER\s+TABLE\b", upper_head):
            self._check_alter_table(s, file, line)
        elif re.match(r"DROP\s+TABLE\b", upper_head):
            self.add(Finding(
                "2.2", LEVEL_MUST, "禁止 DROP TABLE",
                "禁止用 SQL 命令直接删表，需走表下线流程。",
                file, line, _short(s)))
        elif re.match(r"DROP\s+(DATABASE|SCHEMA)\b", upper_head):
            self.add(Finding(
                "2.1", LEVEL_MUST, "禁止 DROP DATABASE",
                "禁止用 SQL 命令直接删库，需走数据库下线流程。",
                file, line, _short(s)))
        elif re.match(r"CREATE\s+(DEFINER\s*=\s*\S+\s+)?(PROCEDURE|FUNCTION)\b", upper_head):
            self.add(Finding(
                "2.11", LEVEL_MUST, "禁止存储过程/函数",
                "禁止使用存储过程/函数（难调试、难扩展、不可移植）。",
                file, line, _short(s)))
        elif re.match(r"CALL\s+\w", upper_head):
            self.add(Finding(
                "2.11", LEVEL_MUST, "禁止 CALL 存储过程",
                "禁止调用存储过程。",
                file, line, _short(s)))
        elif re.match(r"INSERT\s+(IGNORE\s+)?INTO\b", upper_head):
            self._check_insert(s, file, line)
        elif re.match(r"REPLACE\s+INTO\b", upper_head):
            self._check_insert(s, file, line)
        elif re.match(r"UPDATE\b", upper_head):
            self._check_update_delete(s, file, line, kind="UPDATE")
            self._check_dml_common(s, file, line)
        elif re.match(r"DELETE\b", upper_head):
            self._check_update_delete(s, file, line, kind="DELETE")
            self._check_dml_common(s, file, line)
        elif re.match(r"SELECT\b", upper_head):
            self._check_select(s, file, line)
            self._check_dml_common(s, file, line)

    # === DDL: CREATE DATABASE ===
    def _check_create_database(self, s: str, file: str, line: int):
        m = RE_CREATE_DATABASE.search(s)
        if not m:
            return
        opts = m.group(2) or ""
        opts_upper = opts.upper()
        # 1.1.3 必须指定字符集
        cs_match = re.search(r"(?:CHARACTER\s+SET|CHARSET)\s*=?\s*([\w]+)", opts, re.IGNORECASE)
        if not cs_match:
            self.add(Finding(
                "1.1.3", LEVEL_MUST, "建库必须指定字符集",
                "CREATE DATABASE 必须显式 CHARACTER SET / CHARSET，且只能为 utf8 或 utf8mb4（推荐 utf8mb4）。",
                file, line, _short(s)))
        else:
            cs = cs_match.group(1).lower()
            if cs not in ("utf8", "utf8mb4", "utf8mb3"):
                self.add(Finding(
                    "1.1.3", LEVEL_MUST, "字符集只能为 utf8 / utf8mb4",
                    f"当前字符集 `{cs}`，必须改为 utf8 或 utf8mb4（推荐 utf8mb4）。",
                    file, line, _short(s)))

    # === DDL: CREATE TABLE ===
    def _check_create_table(self, s: str, file: str, line: int):
        # 提取表名 + 括号体
        m = re.search(r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?[`\"]?(\w+)[`\"]?\s*\(", s, re.IGNORECASE)
        if not m:
            return
        tbl = m.group(1)
        body_start = s.index("(", m.end() - 1)
        # 找匹配的右括号
        depth = 0
        i = body_start
        in_q = None
        end = -1
        while i < len(s):
            ch = s[i]
            if in_q:
                if ch == "\\" and i + 1 < len(s):
                    i += 2
                    continue
                if ch == in_q:
                    in_q = None
                i += 1
                continue
            if ch in ("'", '"', "`"):
                in_q = ch
                i += 1
                continue
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    end = i
                    break
            i += 1
        if end == -1:
            return
        body = s[body_start + 1: end]
        tail = s[end + 1:]  # ENGINE / CHARSET / COMMENT 等

        # 1.1.1 表名保留字
        self._check_reserved_identifier(tbl, "表名", file, line, s)
        # 1.2.1 表名命名（命中项目配置的占位符片段时跳过，建议 11 的占位符部分顺带在 1.2.1 上生效）
        if not self.config.is_placeholder_table(tbl):
            self._check_lower_snake(tbl, "表名", file, line, s)
        # 1.2.4 长度
        if len(tbl) > 32:
            self.add(Finding(
                "1.2.4", LEVEL_RECOMMEND, "表名长度过长",
                f"表名 `{tbl}` 长度 {len(tbl)} > 32 字符。",
                file, line, _short(s)))

        # 解析列与约束
        items = split_columns_block(body)
        columns: list[dict] = []
        primary_keys: list[str] = []
        unique_keys: list[tuple[str, list[str]]] = []
        normal_keys: list[tuple[str, list[str]]] = []
        has_foreign_key = False
        has_inline_pk = False
        inline_pk_col: str | None = None
        inline_pk_unsigned = False
        inline_pk_type = ""

        for raw in items:
            item = raw.strip().rstrip(",").strip()
            if not item:
                continue
            head_upper = item.upper()
            if head_upper.startswith("PRIMARY KEY"):
                cols_match = re.search(r"PRIMARY\s+KEY\s*\(([^)]+)\)", item, re.IGNORECASE)
                if cols_match:
                    primary_keys.extend(_split_idx_cols(cols_match.group(1)))
                continue
            if head_upper.startswith(("UNIQUE KEY", "UNIQUE INDEX", "UNIQUE (")):
                m2 = re.search(r"UNIQUE\s+(?:KEY|INDEX)?\s*[`\"]?(\w*)[`\"]?\s*\(([^)]+)\)", item, re.IGNORECASE)
                if m2:
                    name = m2.group(1) or ""
                    cols = _split_idx_cols(m2.group(2))
                    unique_keys.append((name, cols))
                continue
            if head_upper.startswith(("KEY ", "INDEX ", "KEY(", "INDEX(")):
                m2 = re.search(r"(?:KEY|INDEX)\s+[`\"]?(\w+)[`\"]?\s*\(([^)]+)\)", item, re.IGNORECASE)
                if m2:
                    normal_keys.append((m2.group(1), _split_idx_cols(m2.group(2))))
                continue
            if head_upper.startswith(("CONSTRAINT", "FOREIGN KEY")):
                if "FOREIGN KEY" in head_upper or "REFERENCES" in head_upper:
                    has_foreign_key = True
                # 当一个 CONSTRAINT 子句包含 PRIMARY KEY / UNIQUE 时也要识别
                if "PRIMARY KEY" in head_upper:
                    cols_match = re.search(r"PRIMARY\s+KEY\s*\(([^)]+)\)", item, re.IGNORECASE)
                    if cols_match:
                        primary_keys.extend(_split_idx_cols(cols_match.group(1)))
                if "UNIQUE" in head_upper:
                    m2 = re.search(r"UNIQUE\s+(?:KEY|INDEX)?\s*[`\"]?(\w*)[`\"]?\s*\(([^)]+)\)", item, re.IGNORECASE)
                    if m2:
                        unique_keys.append((m2.group(1) or "", _split_idx_cols(m2.group(2))))
                continue
            if head_upper.startswith(("FULLTEXT", "SPATIAL")):
                continue
            # 普通列定义
            col = _parse_column(item)
            if col is None:
                continue
            columns.append(col)
            if col.get("inline_primary"):
                has_inline_pk = True
                inline_pk_col = col["name"]
                inline_pk_unsigned = col.get("unsigned", False)
                inline_pk_type = col.get("type", "")

        # 1.1.17 禁止外键
        if has_foreign_key:
            self.add(Finding(
                "1.1.17", LEVEL_MUST, "禁止外键",
                "禁止使用 FOREIGN KEY / REFERENCES 外键约束。",
                file, line, _short(s)))

        # 1.1.9 必须显式声明主键
        if not has_inline_pk and not primary_keys:
            self.add(Finding(
                "1.1.9", LEVEL_MUST, "必须显式声明主键",
                "CREATE TABLE 必须显式声明 PRIMARY KEY，不允许省略。",
                file, line, _short(s)))

        # 1.1.10 主键 bigint unsigned
        pk_cols_for_type_check: list[dict] = []
        if has_inline_pk and inline_pk_col:
            pk_cols_for_type_check.extend([c for c in columns if c["name"] == inline_pk_col])
        if primary_keys:
            for pkc in primary_keys:
                pk_cols_for_type_check.extend([c for c in columns if c["name"].lower() == pkc.lower()])
        for c in pk_cols_for_type_check:
            t = c.get("type", "").lower()
            if "bigint" not in t:
                self.add(Finding(
                    "1.1.10", LEVEL_MUST, "主键必须为 bigint",
                    f"主键列 `{c['name']}` 类型为 `{c.get('type', '')}`，应为 bigint（推荐 unsigned）。",
                    file, line, _short(s)))
            elif not c.get("unsigned"):
                self.add(Finding(
                    "1.1.10", LEVEL_RECOMMEND, "主键建议 bigint unsigned",
                    f"主键列 `{c['name']}` 建议加 unsigned。",
                    file, line, _short(s)))

        # 1.1.11 索引列 NOT NULL
        all_index_cols: list[str] = []
        all_index_cols.extend(primary_keys)
        if has_inline_pk and inline_pk_col:
            all_index_cols.append(inline_pk_col)
        for _, cols in unique_keys:
            all_index_cols.extend(cols)
        for _, cols in normal_keys:
            all_index_cols.extend(cols)
        col_by_name = {c["name"].lower(): c for c in columns}
        seen_idx_col = set()
        for raw_idx_col in all_index_cols:
            ic = raw_idx_col.lower()
            if ic in seen_idx_col:
                continue
            seen_idx_col.add(ic)
            c = col_by_name.get(ic)
            if c and not c.get("not_null"):
                self.add(Finding(
                    "1.1.11", LEVEL_MUST, "索引列必须 NOT NULL",
                    f"索引列 `{c['name']}` 没有 NOT NULL 约束。",
                    file, line, _short(s)))

        # 1.2.2 索引命名
        if has_inline_pk:
            pass  # 内联主键不需命名
        for name, cols in unique_keys:
            if name and not name.startswith("uk_"):
                self.add(Finding(
                    "1.2.2", LEVEL_RECOMMEND, "唯一索引命名应以 uk_ 开头",
                    f"索引 `{name}` 建议改为 `uk_<字段名>`。",
                    file, line, _short(s)))
        for name, cols in normal_keys:
            if name and not name.startswith("idx_"):
                self.add(Finding(
                    "1.2.2", LEVEL_RECOMMEND, "普通索引命名应以 idx_ 开头",
                    f"索引 `{name}` 建议改为 `idx_<字段名>`。",
                    file, line, _short(s)))

        # 1.3.5 varchar 索引必须指定前缀长度
        for kind, idx_list in (("UNIQUE", unique_keys), ("INDEX", normal_keys)):
            for name, cols in idx_list:
                for raw_col in cols:
                    base, prefix_len = _parse_idx_col(raw_col)
                    c = col_by_name.get(base.lower())
                    if c and c.get("type", "").lower().startswith("varchar") and prefix_len is None:
                        self.add(Finding(
                            "1.3.5", LEVEL_RECOMMEND, "varchar 索引未指定前缀长度",
                            f"{kind} `{name or '(匿名)'}` 中 varchar 列 `{base}` 未指定索引前缀长度。",
                            file, line, _short(s)))

        # 列级检查
        col_names_lower = [c["name"].lower() for c in columns]
        time_cols: list[dict] = []
        for c in columns:
            cname = c["name"]
            ctype_full = c.get("type", "")
            ctype = ctype_full.lower()
            # 1.1.1 字段名保留字
            self._check_reserved_identifier(cname, "字段名", file, line, s)
            # 1.2.1 命名
            self._check_lower_snake(cname, "字段名", file, line, s)
            # 1.2.4 长度
            if len(cname) > 32:
                self.add(Finding(
                    "1.2.4", LEVEL_RECOMMEND, "字段名长度过长",
                    f"字段 `{cname}` 长度 {len(cname)} > 32 字符。",
                    file, line, _short(s)))
            # 1.1.7 禁止 float / double
            if re.match(r"\b(float|double|real)\b", ctype):
                self.add(Finding(
                    "1.1.7", LEVEL_MUST, "禁止 float / double",
                    f"字段 `{cname}` 使用了 `{ctype_full}`，小数请使用 decimal。",
                    file, line, _short(s)))
            # 1.1.15 禁止 enum
            if ctype.startswith("enum"):
                self.add(Finding(
                    "1.1.15", LEVEL_MUST, "禁止 ENUM",
                    f"字段 `{cname}` 使用了 ENUM 类型，建议改为 tinyint/smallint/char。",
                    file, line, _short(s)))
            # 1.3.3 不建议 TEXT/BLOB
            if re.match(r"\b(tinytext|text|mediumtext|longtext|tinyblob|blob|mediumblob|longblob)\b", ctype):
                self.add(Finding(
                    "1.3.3", LEVEL_RECOMMEND, "不建议使用 TEXT/BLOB",
                    f"字段 `{cname}` 类型 `{ctype_full}`，建议拆到独立表用主键关联。",
                    file, line, _short(s)))
            # 1.1.20 字段必须有 COMMENT
            if not c.get("comment"):
                self.add(Finding(
                    "1.1.20", LEVEL_MUST, "字段必须带 COMMENT",
                    f"字段 `{cname}` 缺少 COMMENT 注释。",
                    file, line, _short(s)))
            # 1.1.13 NOT NULL 推荐带 DEFAULT
            if c.get("not_null") and not c.get("has_default") \
                    and not c.get("auto_increment") \
                    and not re.match(r"\b(text|blob|mediumtext|longtext|tinytext|mediumblob|longblob|tinyblob|json)\b", ctype):
                self.add(Finding(
                    "1.1.13", LEVEL_RECOMMEND, "NOT NULL 列建议带默认值",
                    f"字段 `{cname}` 是 NOT NULL，建议添加 DEFAULT。",
                    file, line, _short(s)))
            # 1.1.14 timestamp/datetime 建议有默认值
            if re.match(r"\b(timestamp|datetime)\b", ctype) and not c.get("has_default"):
                self.add(Finding(
                    "1.1.14", LEVEL_RECOMMEND, "时间类型列建议有默认值",
                    f"字段 `{cname}` 类型 `{ctype_full}` 建议添加 DEFAULT。",
                    file, line, _short(s)))
                time_cols.append(c)
            # 1.2.5 时间字段命名后缀
            if re.match(r"\b(timestamp|datetime)\b", ctype):
                if not (cname.endswith("_at") or cname.endswith("_time")):
                    self.add(Finding(
                        "1.2.5", LEVEL_RECOMMEND, "时间戳字段命名建议以 _at 结尾",
                        f"字段 `{cname}` 是时间戳/时间类型，建议命名以 `_at` 结尾。",
                        file, line, _short(s)))
            if re.match(r"\bdate\b", ctype):
                if not cname.endswith("_date"):
                    self.add(Finding(
                        "1.2.5", LEVEL_RECOMMEND, "日期字段命名建议以 _date 结尾",
                        f"字段 `{cname}` 类型 date，建议命名以 `_date` 结尾。",
                        file, line, _short(s)))

        # 1.1.18 表字段数 < 99
        if len(columns) >= 99:
            self.add(Finding(
                "1.1.18", LEVEL_RECOMMEND, "表字段数过多",
                f"表 `{tbl}` 字段数 {len(columns)} >= 99，建议拆表。",
                file, line, _short(s)))

        # 1.1.19 必备字段 id / create_at / update_at（命名族放宽，详见建议 10）
        col_names_set = set(col_names_lower)
        for required in ("id", "create_at", "update_at"):
            accepted = self.config.required_field_aliases(required)
            if not (col_names_set & accepted):
                # 提示信息明确列出可接受的命名族，避免反复返工
                if len(accepted) > 1:
                    hint = "、".join(f"`{n}`" for n in sorted(accepted))
                    msg = f"表 `{tbl}` 缺少必备字段（语义：`{required}`），可接受的命名任选其一：{hint}。"
                else:
                    msg = f"表 `{tbl}` 缺少必备字段 `{required}`。"
                self.add(Finding(
                    "1.1.19", LEVEL_RECOMMEND, "缺失必备字段",
                    msg, file, line, _short(s)))

        # 表级 ENGINE / CHARSET / COLLATE / COMMENT 检查
        tail_upper = tail.upper()
        # 1.1.2 InnoDB
        m_eng = re.search(r"ENGINE\s*=\s*(\w+)", tail, re.IGNORECASE)
        if m_eng:
            eng = m_eng.group(1).lower()
            if eng != "innodb":
                self.add(Finding(
                    "1.1.2", LEVEL_RECOMMEND, "存储引擎建议 InnoDB",
                    f"表 `{tbl}` ENGINE=`{eng}`，默认建议 InnoDB；有事务必须 InnoDB。",
                    file, line, _short(s)))
        # 1.1.4 字符集推荐 utf8mb4
        m_cs = re.search(r"(?:DEFAULT\s+)?(?:CHARACTER\s+SET|CHARSET)\s*=?\s*([\w]+)", tail, re.IGNORECASE)
        if m_cs:
            cs = m_cs.group(1).lower()
            if cs not in ("utf8mb4", "utf8", "utf8mb3"):
                self.add(Finding(
                    "1.1.4", LEVEL_RECOMMEND, "字符集建议 utf8mb4",
                    f"表 `{tbl}` 字符集 `{cs}`，建议 utf8mb4（必要时 utf8）。",
                    file, line, _short(s)))
        # 1.1.6 COLLATE 不要 _bin
        m_co = re.search(r"COLLATE\s*=?\s*([\w]+)", tail, re.IGNORECASE)
        if m_co and m_co.group(1).lower().endswith("_bin"):
            self.add(Finding(
                "1.1.6", LEVEL_RECOMMEND, "字符序避免 *_bin",
                f"表 `{tbl}` COLLATE=`{m_co.group(1)}`，大小写敏感排序规则不推荐。",
                file, line, _short(s)))
        # 1.1.20 表必须有 COMMENT
        if "COMMENT" not in tail_upper:
            self.add(Finding(
                "1.1.20", LEVEL_MUST, "表必须带 COMMENT",
                f"表 `{tbl}` 缺少表级 COMMENT 注释。",
                file, line, _short(s)))

    # === DDL: ALTER TABLE ===
    def _check_alter_table(self, s: str, file: str, line: int):
        upper = s.upper()
        # 2.4 禁止删列
        if re.search(r"\bDROP\s+COLUMN\b", upper):
            self.add(Finding(
                "2.4", LEVEL_MUST, "禁止删除列",
                "ALTER TABLE ... DROP COLUMN 不被允许。",
                file, line, _short(s)))

    # === DML ===
    def _check_insert(self, s: str, file: str, line: int):
        # 2.5 INSERT 必须显式字段名
        m = re.search(
            r"\b(?:INSERT|REPLACE)\s+(?:IGNORE\s+|LOW_PRIORITY\s+|DELAYED\s+|HIGH_PRIORITY\s+)?INTO\s+[`\"]?\w+[`\"]?\s*([^V])",
            s, re.IGNORECASE)
        # 简单的判定方法：查找 INTO <table> 后紧跟 VALUES 或 SELECT，而没有括号字段列表
        m2 = re.search(
            r"\bINTO\s+[`\"]?\w+[`\"]?\s*(\([^)]*\))?\s*(VALUES|SELECT|SET|VALUE)",
            s, re.IGNORECASE)
        if m2 and m2.group(1) is None and m2.group(2).upper() in ("VALUES", "VALUE", "SELECT"):
            self.add(Finding(
                "2.5", LEVEL_MUST, "INSERT 必须显式列出字段名",
                "INSERT/REPLACE 语句必须在表名后显式列出字段名。",
                file, line, _short(s)))

    def _check_update_delete(self, s: str, file: str, line: int, kind: str):
        # 2.6 UPDATE/DELETE 必须 WHERE
        upper = s.upper()
        # DELETE FROM tbl 且无 WHERE
        if not re.search(r"\bWHERE\b", upper):
            self.add(Finding(
                "2.6", LEVEL_MUST, f"{kind} 必须带 WHERE",
                f"{kind} 语句必须带 WHERE 条件，避免误操作与全表扫描。",
                file, line, _short(s)))

    def _check_select(self, s: str, file: str, line: int):
        upper = s.upper()
        # 2.6 SELECT 不带 WHERE 也告警（推荐级，避免误伤聚合查询？这里按 MUST 维持原文）
        # 文档原话："禁止 select 不带 where" → MUST
        # 但 SELECT 1 / SELECT NOW() / SELECT FROM DUAL 这类不需要 WHERE，做精细化判断
        if re.search(r"\bFROM\b", upper) and not re.search(r"\bWHERE\b", upper):
            # 排除 INFORMATION_SCHEMA / DUAL / system tables
            if not re.search(r"\bFROM\s+(DUAL|INFORMATION_SCHEMA\b|MYSQL\.\w+)", upper):
                self.add(Finding(
                    "2.6", LEVEL_MUST, "SELECT 不带 WHERE",
                    "SELECT 语句没有 WHERE 条件，可能导致全表扫描，请补全条件或用 LIMIT 控制。",
                    file, line, _short(s)))

        # 2.8 SELECT *
        if re.search(r"SELECT\s+\*", upper) and not re.search(r"COUNT\s*\(\s*\*\s*\)", upper) \
                and not re.search(r"EXISTS\s*\(\s*SELECT\s+\*", upper):
            # 避免误报子查询里 EXISTS(SELECT * ...)，但 EXISTS 内部 SELECT * 是惯用法，跳过
            self.add(Finding(
                "2.8", LEVEL_RECOMMEND, "避免 SELECT *",
                "建议明确指定 SELECT 字段，避免 SELECT *。",
                file, line, _short(s)))

        # 2.16 count(列名)/count(1) 提示
        for m in re.finditer(r"\bCOUNT\s*\(\s*([^)]*?)\s*\)", upper):
            arg = m.group(1).strip()
            if arg in ("*",):
                continue
            if arg in ("1",) or re.match(r"^[`\"\w.]+$", arg):
                self.add(Finding(
                    "2.16", LEVEL_RECOMMEND, "建议使用 count(*)",
                    f"COUNT({arg}) 建议改为 COUNT(*)（标准统计行数语法）。",
                    file, line, _short(s)))
                break

    # === DML 通用检查 ===
    def _check_dml_common(self, s: str, file: str, line: int):
        upper = s.upper()

        # 2.10 三表以上 JOIN
        join_count = len(re.findall(r"\b(?:INNER|LEFT|RIGHT|CROSS|FULL|OUTER)?\s*JOIN\b", upper))
        if join_count >= 3:  # 主表 + 3 个 JOIN = 4 张表 > 3，触发；按文档"超过三个表禁止 join"
            tables = 1 + join_count
            if tables > 3:
                self.add(Finding(
                    "2.10", LEVEL_MUST, "JOIN 表数量超过 3",
                    f"该语句涉及 {tables} 张表的 JOIN，超过 3 张表禁止 JOIN。",
                    file, line, _short(s)))

        # 2.13 全/左模糊
        for m in re.finditer(r"\bLIKE\s+(['\"])(%[^'\"]*)\1", s, re.IGNORECASE):
            pattern = m.group(2)
            self.add(Finding(
                "2.13", LEVEL_RECOMMEND, "避免左模糊/全模糊",
                f"LIKE `{pattern}` 以 `%` 开头会导致索引失效。",
                file, line, _short(s)))

        # 2.14 IN(...) 元素 > 200
        for m in re.finditer(r"\bIN\s*\(([^()]*)\)", s, re.IGNORECASE):
            inside = m.group(1)
            # 排除子查询 IN (SELECT ...)
            if re.match(r"\s*SELECT\b", inside, re.IGNORECASE):
                continue
            # 粗略数元素
            n_items = len([x for x in inside.split(",") if x.strip()])
            if n_items > 200:
                self.add(Finding(
                    "2.14", LEVEL_RECOMMEND, "IN 列表过长",
                    f"IN(...) 中元素 {n_items} 个，建议控制在 200 以内。",
                    file, line, _short(s)))

        # 2.18 ORDER BY RAND()
        if re.search(r"ORDER\s+BY\s+RAND\s*\(", upper):
            self.add(Finding(
                "2.18", LEVEL_RECOMMEND, "禁止 ORDER BY RAND()",
                "ORDER BY RAND() 性能很差，建议改用其他随机方案。",
                file, line, _short(s)))

        # 2.9 索引列函数表达式（粗判）：WHERE 中 col 包在函数里
        # 形如 WHERE DATE(col) = ... / UPPER(col) = ...
        m_where = re.search(r"\bWHERE\b(.+?)(?:\bGROUP\s+BY\b|\bORDER\s+BY\b|\bLIMIT\b|$)", upper, re.DOTALL)
        if m_where:
            wclause = m_where.group(1)
            for fn in ("DATE", "UPPER", "LOWER", "SUBSTRING", "LEFT", "RIGHT", "TRIM", "CONCAT", "IFNULL", "DATE_FORMAT", "FROM_UNIXTIME", "UNIX_TIMESTAMP"):
                if re.search(rf"\b{fn}\s*\(\s*[`\"]?\w+[`\"]?\s*[,\)]", wclause):
                    self.add(Finding(
                        "2.9", LEVEL_RECOMMEND, "WHERE 中索引列嵌套函数",
                        f"WHERE 子句中疑似对列使用了 `{fn}(...)`，可能导致索引失效。",
                        file, line, _short(s)))
                    break

        # 2.15 = NULL / <> NULL / != NULL
        if re.search(r"(?:=|<>|!=)\s*NULL\b", upper):
            self.add(Finding(
                "2.15", LEVEL_RECOMMEND, "NULL 比较应使用 IS NULL / ISNULL()",
                "= NULL / <> NULL / != NULL 永远返回 NULL，请使用 IS NULL / IS NOT NULL / ISNULL()。",
                file, line, _short(s)))

    # === 工具：保留字 / 命名 ===
    def _check_reserved_identifier(self, ident: str, kind: str, file: str, line: int, s: str):
        if ident.lower() in RESERVED_WORDS:
            self.add(Finding(
                "1.1.1", LEVEL_MUST, f"{kind}使用了保留字",
                f"{kind} `{ident}` 是 MySQL 保留字，必须改名。",
                file, line, _short(s)))

    def _check_lower_snake(self, ident: str, kind: str, file: str, line: int, s: str):
        # 1.2.1 小写字母+数字+下划线；不以数字开头；不以下划线结尾；两个下划线之间不能仅是数字
        if not re.match(r"^[a-z][a-z0-9_]*$", ident):
            self.add(Finding(
                "1.2.1", LEVEL_MUST, f"{kind}命名不规范",
                f"{kind} `{ident}` 必须使用小写字母+数字+下划线，不能数字开头，不能含大写。",
                file, line, _short(s)))
            return
        if ident.endswith("_"):
            self.add(Finding(
                "1.2.1", LEVEL_MUST, f"{kind}不能以下划线结尾",
                f"{kind} `{ident}` 不能以下划线结尾。",
                file, line, _short(s)))
        if re.search(r"_\d+_", ident):
            self.add(Finding(
                "1.2.1", LEVEL_MUST, f"{kind}两个下划线之间不能仅为数字",
                f"{kind} `{ident}` 中存在 `_<数字>_` 模式，不允许。",
                file, line, _short(s)))


# -------------------- 解析辅助 --------------------

def _split_idx_cols(s: str) -> list[str]:
    parts = []
    for raw in s.split(","):
        x = raw.strip().strip("`\"")
        if x:
            parts.append(x)
    return parts


def _parse_idx_col(raw: str) -> tuple[str, int | None]:
    """解析索引列 `col(20)` → ("col", 20)。"""
    raw = raw.strip().strip("`\"")
    m = re.match(r"^([^\s(]+)(?:\((\d+)\))?", raw)
    if not m:
        return raw, None
    return m.group(1), (int(m.group(2)) if m.group(2) else None)


def _parse_column(item: str) -> dict | None:
    """把一个列定义字符串解析为 dict。"""
    m = re.match(r"^[`\"]?(\w+)[`\"]?\s+([A-Za-z]+)\s*(\([^)]*\))?\s*(.*)$", item.strip(), re.DOTALL)
    if not m:
        return None
    name = m.group(1)
    type_name = m.group(2)
    type_args = m.group(3) or ""
    rest = m.group(4) or ""
    rest_upper = rest.upper()
    full_type = (type_name + type_args).lower()
    not_null = "NOT NULL" in rest_upper
    nullable_explicit = "NULL" in rest_upper and "NOT NULL" not in rest_upper
    has_default = re.search(r"\bDEFAULT\b", rest_upper) is not None
    auto_inc = "AUTO_INCREMENT" in rest_upper
    unsigned = "UNSIGNED" in rest_upper
    inline_primary = "PRIMARY KEY" in rest_upper
    comment_match = re.search(r"COMMENT\s+'((?:[^'\\]|\\.|'')*)'", rest, re.IGNORECASE)
    comment = comment_match.group(1) if comment_match else ""
    return {
        "name": name,
        "type": full_type,
        "type_name": type_name.lower(),
        "not_null": not_null,
        "nullable": nullable_explicit,
        "has_default": has_default,
        "auto_increment": auto_inc,
        "unsigned": unsigned,
        "inline_primary": inline_primary,
        "comment": comment,
    }


def _short(s: str, n: int = 200) -> str:
    s = " ".join(s.split())
    return s if len(s) <= n else s[:n] + "..."


# -------------------- 文件读取 --------------------

def iter_files(paths: list[str]) -> Iterable[Path]:
    for p in paths:
        path = Path(p)
        if path.is_file():
            yield path
        elif path.is_dir():
            for ext in [".sql"] + list(SOURCE_EXTS):
                for f in path.rglob(f"*{ext}"):
                    if any(part in {".git", "node_modules", "vendor", "build", "dist", ".venv", "__pycache__"} for part in f.parts):
                        continue
                    yield f


def read_text(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return p.read_text(encoding="latin-1", errors="replace")


def file_to_blocks(p: Path) -> list[SqlBlock]:
    text = read_text(p)
    if p.suffix.lower() == ".sql":
        return [SqlBlock(text, str(p), 1)]
    if p.suffix.lower() in SOURCE_EXTS:
        return extract_sql_blocks_from_source(text, str(p))
    return []


# -------------------- Git Diff（增量模式） --------------------

class DiffError(RuntimeError):
    pass


def _run_git(args: list[str], cwd: Path) -> str:
    try:
        out = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        return out.stdout
    except FileNotFoundError as e:
        raise DiffError("未找到 git 可执行文件，无法启用增量模式。") from e
    except subprocess.CalledProcessError as e:
        raise DiffError(
            f"git 命令执行失败: git {' '.join(args)}\nstderr: {e.stderr.strip()}"
        ) from e


def find_repo_root(paths: list[str]) -> Path:
    """从用户传入的目标路径找 git 仓库根。优先用第一个路径所在目录向上找。"""
    if not paths:
        raise DiffError("未提供检查目标路径。")
    anchor = Path(paths[0]).resolve()
    if anchor.is_file():
        anchor = anchor.parent
    out = _run_git(["rev-parse", "--show-toplevel"], anchor)
    root = out.strip()
    if not root:
        raise DiffError(f"路径 {anchor} 不在 git 仓库内，无法启用增量模式。")
    return Path(root)


def parse_unified_diff(diff_text: str) -> dict[str, set[int]]:
    """解析 git diff（unified=0）输出，返回 {绝对路径或仓库相对路径 → 新增行号集合}。

    - 删除的文件：跳过（不出现在结果里）。
    - 二进制文件：跳过。
    - 新增的整文件：所有行都视为新增。
    """
    changed: dict[str, set[int]] = {}
    cur_file: str | None = None
    skip_current = False
    lines = diff_text.splitlines()
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        if line.startswith("diff --git "):
            cur_file = None
            skip_current = False
            # 预读后续 header，决定文件名与是否跳过
            j = i + 1
            new_path: str | None = None
            is_binary = False
            is_deleted = False
            while j < n and not lines[j].startswith("diff --git ") and not lines[j].startswith("@@"):
                hl = lines[j]
                if hl.startswith("deleted file mode"):
                    is_deleted = True
                elif hl.startswith("Binary files ") or hl.startswith("GIT binary patch"):
                    is_binary = True
                elif hl.startswith("+++ "):
                    target = hl[4:].strip()
                    if target == "/dev/null":
                        is_deleted = True
                    else:
                        # 形如 b/path/to/file
                        new_path = target[2:] if target.startswith("b/") else target
                j += 1
            if is_deleted or is_binary or not new_path:
                skip_current = True
            else:
                cur_file = new_path
                changed.setdefault(cur_file, set())
            i = j
            continue
        if line.startswith("@@") and cur_file and not skip_current:
            # @@ -a,b +c,d @@  其中 ,b / ,d 可省略（默认 1）
            m = re.match(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@", line)
            if m:
                start = int(m.group(1))
                count = int(m.group(2)) if m.group(2) is not None else 1
                if count > 0:
                    for ln in range(start, start + count):
                        changed[cur_file].add(ln)
        i += 1
    # 清理空集合（纯重命名 / 纯删除）
    return {k: v for k, v in changed.items() if v}


def collect_changed_lines(repo_root: Path, diff_ref: str | None) -> dict[str, set[int]]:
    """
    返回 {文件绝对路径 → 新增行号集合}。

    - diff_ref 为 None / "" → 取工作区相对 HEAD 的改动（含未暂存 + 已暂存 + 未跟踪整文件）。
    - 否则透传给 `git diff <ref> --unified=0` 使用。

    会排除 skill 自身的工作目录 `.qiqskills/`，避免本轮落盘的 patch / report 被当成输入。
    """
    changed: dict[str, set[int]] = {}
    skip_prefix = ".qiqskills/"

    def _merge(other: dict[str, set[int]]):
        for k, v in other.items():
            if k.startswith(skip_prefix):
                continue
            abspath = str((repo_root / k).resolve())
            changed.setdefault(abspath, set()).update(v)

    if not diff_ref:
        # 已暂存
        cached = _run_git(["diff", "--cached", "--unified=0", "--no-color"], repo_root)
        _merge(parse_unified_diff(cached))
        # 未暂存
        unstaged = _run_git(["diff", "--unified=0", "--no-color"], repo_root)
        _merge(parse_unified_diff(unstaged))
        # 未跟踪文件 → 视为整文件新增
        untracked = _run_git(
            ["ls-files", "--others", "--exclude-standard"], repo_root
        ).splitlines()
        for rel in untracked:
            rel = rel.strip()
            if not rel or rel.startswith(skip_prefix):
                continue
            fp = (repo_root / rel).resolve()
            try:
                if not fp.is_file():
                    continue
                line_count = sum(1 for _ in fp.open("rb")) or 1
            except OSError:
                continue
            changed.setdefault(str(fp), set()).update(range(1, line_count + 1))
    else:
        out = _run_git(
            ["diff", diff_ref, "--unified=0", "--no-color"], repo_root
        )
        _merge(parse_unified_diff(out))
    return changed


def _raw_diff(repo_root: Path, diff_ref: str | None) -> str:
    """为留痕保存的 patch 文本（保留正常 unified context，便于人看）。"""
    if not diff_ref:
        parts = []
        parts.append(_run_git(["diff", "--cached", "--no-color"], repo_root))
        parts.append(_run_git(["diff", "--no-color"], repo_root))
        return "\n".join(p for p in parts if p)
    return _run_git(["diff", diff_ref, "--no-color"], repo_root)


def filter_findings_by_changed_lines(
    findings: list[Finding], changed: dict[str, set[int]]
) -> list[Finding]:
    """按「文件 + 行号 是否落在新增行集合」过滤 findings。"""
    if not changed:
        return []
    # 把 key 全部规范成 resolved 绝对路径，便于匹配
    norm: dict[str, set[int]] = {}
    for k, v in changed.items():
        try:
            norm[str(Path(k).resolve())] = v
        except OSError:
            norm[k] = v
    kept: list[Finding] = []
    for f in findings:
        try:
            key = str(Path(f.file).resolve())
        except OSError:
            key = f.file
        lines = norm.get(key)
        if not lines:
            continue
        if f.line and f.line in lines:
            kept.append(f)
    return kept


# -------------------- 报告输出 --------------------

def _classify_finding(f: Finding, cfg: ProjectConfig) -> str:
    """返回分组标签：'upstream' / 'suspect' / 'real'。

    仅用于报告分档。不会改变判定本身。
    """
    fp = f.file.replace("\\", "/").lower()
    # 1) 明确命中项目配置 excluded_paths → 上游/历史兼容
    if cfg and cfg.is_excluded(f.file):
        return "upstream"
    # 2) 路径包含上游项目关键字 / 测试 fixture → 上游/历史兼容
    if any(h in fp for h in UPSTREAM_PATH_HINTS):
        return "upstream"
    if any(h in fp for h in TEST_FIXTURE_PATH_HINTS):
        return "upstream"
    # 3) 占位符表名相关的常见误报（如果某条违规消息里出现了配置的占位符片段）→ 疑似误报
    if cfg and cfg.table_name_placeholders:
        msg_lower = (f.message or "").lower()
        for ph in cfg.table_name_placeholders:
            if ph and ph.lower() in msg_lower:
                return "suspect"
    return "real"


def _hint_for(f: Finding, group: str) -> str:
    """为分组后的 finding 生成一句「怎么处理」提示。"""
    if group == "upstream":
        return (
            "建议在 `.audit-sql.json` 的 `excluded_paths` 添加该路径，或在文件顶部加 "
            "`-- audit-sql:disable-file=" + f.rule_id + " reason=upstream` 豁免。"
        )
    if group == "suspect":
        return (
            "看起来是占位符/别名场景，可在该行紧邻上方加 "
            "`-- audit-sql:disable-next-line=" + f.rule_id + " reason=...` 豁免。"
        )
    return ""


def _emit_finding_table(lines: list[str], fs: list[Finding], with_hint: bool, group: str | None):
    lines.append("| 等级 | 规则 | 行号 | 标题 | 说明 |" + (" 处理提示 |" if with_hint else ""))
    lines.append("|---|---|---|---|---|" + ("---|" if with_hint else ""))
    fs_sorted = sorted(fs, key=lambda x: (0 if x.level == LEVEL_MUST else 1, x.rule_id, x.line))
    for f in fs_sorted:
        level_label = "🛑 必须" if f.level == LEVEL_MUST else "⚠️ 推荐"
        msg = f.message.replace("|", "\\|").replace("\n", " ")
        title = f.title.replace("|", "\\|")
        if with_hint:
            hint = _hint_for(f, group or "real").replace("|", "\\|").replace("\n", " ")
            lines.append(f"| {level_label} | {f.rule_id} | {f.line} | {title} | {msg} | {hint} |")
        else:
            lines.append(f"| {level_label} | {f.rule_id} | {f.line} | {title} | {msg} |")
    lines.append("")


def render_markdown(
    findings: list[Finding],
    scanned_files: list[str],
    strict: bool,
    diff_info: dict | None = None,
    config: ProjectConfig | None = None,
) -> str:
    cfg = config or ProjectConfig()
    must = [f for f in findings if f.level == LEVEL_MUST]
    rec = [f for f in findings if f.level == LEVEL_RECOMMEND]
    lines = []
    lines.append("# DB 规范检查报告（qiq-audit-sql）")
    lines.append("")
    lines.append(f"- 扫描文件数：**{len(scanned_files)}**")
    lines.append(f"- 必须级违规：**{len(must)}**")
    lines.append(f"- 推荐级违规：**{len(rec)}**")
    lines.append(f"- 严格模式：**{'是' if strict else '否'}**")
    if cfg and cfg.source_path:
        lines.append(f"- 项目配置：`{cfg.source_path}`")
    if diff_info:
        ref_show = diff_info.get("ref") or "工作区改动 (HEAD vs working tree + index + untracked)"
        lines.append(f"- 增量模式：**行粒度**（基于 git diff: `{ref_show}`）")
        lines.append(
            f"- 增量涉及文件数：**{diff_info.get('changed_file_count', 0)}**，新增/修改行数：**{diff_info.get('changed_line_count', 0)}**"
        )
    lines.append("")
    if not findings:
        lines.append("> ✅ 未发现违规，恭喜通过检查。")
        return "\n".join(lines)

    # 三档分组（建议 3）：real / suspect / upstream
    real: list[Finding] = []
    suspect: list[Finding] = []
    upstream: list[Finding] = []
    for f in findings:
        g = _classify_finding(f, cfg)
        if g == "upstream":
            upstream.append(f)
        elif g == "suspect":
            suspect.append(f)
        else:
            real.append(f)

    lines.append("## 违规概览")
    lines.append("")
    lines.append(f"- 🔴 真违规（建议修复）：**{len(real)}**")
    lines.append(f"- 🟡 疑似误报（建议加豁免注释）：**{len(suspect)}**")
    lines.append(f"- ⚪ 上游/历史兼容（建议加入豁免名单）：**{len(upstream)}**")
    lines.append("")

    def _by_file(group_findings: list[Finding]) -> dict[str, list[Finding]]:
        out: dict[str, list[Finding]] = {}
        for f in group_findings:
            out.setdefault(f.file, []).append(f)
        return out

    if real:
        lines.append("## 🔴 真违规")
        lines.append("")
        for file, fs in _by_file(real).items():
            lines.append(f"### `{file}`")
            lines.append("")
            _emit_finding_table(lines, fs, with_hint=False, group="real")

    if suspect:
        lines.append("## 🟡 疑似误报（建议加豁免）")
        lines.append("")
        for file, fs in _by_file(suspect).items():
            lines.append(f"### `{file}`")
            lines.append("")
            _emit_finding_table(lines, fs, with_hint=True, group="suspect")

    if upstream:
        lines.append("## ⚪ 上游/历史兼容")
        lines.append("")
        for file, fs in _by_file(upstream).items():
            lines.append(f"### `{file}`")
            lines.append("")
            _emit_finding_table(lines, fs, with_hint=True, group="upstream")

    lines.append("## 修复建议")
    lines.append("")
    lines.append("- 🔴 **真违规**优先修复（必须级阐断合流）。")
    lines.append("- 🟡 **疑似误报**：如确认是占位符 / 项目别名场景，加 `audit-sql:disable-next-line=规则号 reason=...` 或调整 `.audit-sql.json`。")
    lines.append("- ⚪ **上游/历史兼容**：推荐加入 `.audit-sql.json` 的 `excluded_paths` 或 `audit-sql:disable-file=...` ，避免持续噪声。")
    lines.append("- 完整规范见 `references/full-spec.md`，机读 checklist 见 `references/checklist.md`。")
    return "\n".join(lines)

def render_json(
    findings: list[Finding],
    scanned_files: list[str],
    strict: bool,
    diff_info: dict | None = None,
    config: ProjectConfig | None = None,
) -> str:
    cfg = config or ProjectConfig()
    summary = {
        "scanned_files": len(scanned_files),
        "must": sum(1 for f in findings if f.level == LEVEL_MUST),
        "recommend": sum(1 for f in findings if f.level == LEVEL_RECOMMEND),
        "strict": strict,
    }
    if cfg.source_path:
        summary["config_path"] = cfg.source_path
    if diff_info:
        summary["diff"] = {
            "mode": "line",
            "ref": diff_info.get("ref"),
            "changed_file_count": diff_info.get("changed_file_count", 0),
            "changed_line_count": diff_info.get("changed_line_count", 0),
        }
    # 给每个 finding 附上分组标签，便于上游消费
    items = []
    for f in findings:
        d = f.to_dict()
        d["group"] = _classify_finding(f, cfg)
        items.append(d)
    summary["by_group"] = {
        "real": sum(1 for d in items if d["group"] == "real"),
        "suspect": sum(1 for d in items if d["group"] == "suspect"),
        "upstream": sum(1 for d in items if d["group"] == "upstream"),
    }
    return json.dumps({
        "summary": summary,
        "findings": items,
    }, ensure_ascii=False, indent=2)


# -------------------- main --------------------

def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description="DB 规范自动检查")
    parser.add_argument("paths", nargs="+", help="要检查的文件或目录")
    parser.add_argument("--strict", action="store_true", help="严格模式：推荐级违规也阻断退出码")
    parser.add_argument("--format", choices=["md", "json"], default="md", help="报告格式")
    parser.add_argument("-o", "--output", help="输出文件路径（默认 stdout）")
    parser.add_argument(
        "--diff",
        nargs="?",
        const="",
        default=None,
        metavar="REF",
        help=(
            "增量模式（行粒度）：只报告落在 git diff 新增/修改行上的违规。"
            "REF 可省略（=工作区未提交改动），也可为 HEAD~1 / origin/master...HEAD 等任意 git diff 接受的引用。"
        ),
    )
    args = parser.parse_args(argv)

    # 项目级配置（建议 2）：从被检查路径向上查找 .audit-sql.json
    project_cfg = load_project_config(args.paths)

    # 增量模式准备
    diff_enabled = args.diff is not None
    diff_ref: str | None = args.diff if (args.diff not in (None, "")) else None
    changed_lines: dict[str, set[int]] = {}
    repo_root: Path | None = None
    workdir: Path | None = None
    if diff_enabled:
        try:
            repo_root = find_repo_root(args.paths)
            workdir = repo_root / WORKDIR_NAME
            workdir.mkdir(parents=True, exist_ok=True)
            # 落盘 diff patch
            patch_text = _raw_diff(repo_root, diff_ref)
            (workdir / "diff.patch").write_text(patch_text, encoding="utf-8")
            changed_lines = collect_changed_lines(repo_root, diff_ref)
            # 落盘 changed-lines.json（行号集合转 list）
            (workdir / "changed-lines.json").write_text(
                json.dumps(
                    {
                        "ref": diff_ref or "",
                        "repo_root": str(repo_root),
                        "files": {k: sorted(v) for k, v in changed_lines.items()},
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
        except DiffError as e:
            print(f"[--diff] {e}", file=sys.stderr)
            return 2
        if not changed_lines:
            # 没有任何增量改动 → 直接返回 0，但仍写一份空报告
            empty_info = {
                "ref": diff_ref,
                "changed_file_count": 0,
                "changed_line_count": 0,
            }
            if args.format == "md":
                report = render_markdown([], [], args.strict, empty_info, project_cfg)
            else:
                report = render_json([], [], args.strict, empty_info, project_cfg)
            if args.output:
                Path(args.output).write_text(report, encoding="utf-8")
            else:
                print(report)
            return 0

    # 选定扫描范围：增量模式下只扫「diff 涉及的文件」交「支持后缀」；否则按 paths 递归。
    if diff_enabled:
        files: list[Path] = []
        for fp_str in changed_lines.keys():
            fp = Path(fp_str)
            if not fp.exists() or not fp.is_file():
                continue
            ext = fp.suffix.lower()
            if ext == ".sql" or ext in SOURCE_EXTS:
                files.append(fp)
    else:
        files = list(iter_files(args.paths))

    if not files:
        if diff_enabled:
            # 增量模式但没有可扫文件（diff 文件都不是 sql/源码）
            empty_info = {
                "ref": diff_ref,
                "changed_file_count": len(changed_lines),
                "changed_line_count": sum(len(v) for v in changed_lines.values()),
            }
            if args.format == "md":
                report = render_markdown([], [], args.strict, empty_info, project_cfg)
            else:
                report = render_json([], [], args.strict, empty_info, project_cfg)
            if args.output:
                Path(args.output).write_text(report, encoding="utf-8")
            else:
                print(report)
            return 0
        print("未找到任何 .sql 或源代码文件。", file=sys.stderr)
        return 2

    auditor = Auditor(config=project_cfg)
    scanned: list[str] = []
    file_exemptions: dict[str, FileExemptions] = {}
    for p in files:
        scanned.append(str(p))
        # 先采集豁免指令（建议 1），key 用与 Finding.file 一致的字符串
        try:
            file_text = read_text(p)
            file_exemptions[str(p)] = collect_exemptions(file_text, str(p))
        except OSError:
            pass
        for block in file_to_blocks(p):
            auditor.audit_block(block)

    # 应用豁免过滤：仅依赖 finding.file + finding.line
    raw_findings = auditor.findings
    findings: list[Finding] = []
    for f in raw_findings:
        ex = file_exemptions.get(f.file)
        if ex and ex.covers(f.rule_id, f.line):
            continue
        findings.append(f)
    diff_info: dict | None = None
    if diff_enabled:
        findings = filter_findings_by_changed_lines(findings, changed_lines)
        diff_info = {
            "ref": diff_ref,
            "changed_file_count": len(changed_lines),
            "changed_line_count": sum(len(v) for v in changed_lines.values()),
        }

    if args.format == "md":
        report = render_markdown(findings, scanned, args.strict, diff_info, project_cfg)
    else:
        report = render_json(findings, scanned, args.strict, diff_info, project_cfg)

    if args.output:
        Path(args.output).write_text(report, encoding="utf-8")
    else:
        print(report)

    # 增量模式下也把报告留痕到工作目录，便于排查
    if diff_enabled and workdir is not None:
        ext = "md" if args.format == "md" else "json"
        (workdir / f"report.{ext}").write_text(report, encoding="utf-8")

    has_must = any(f.level == LEVEL_MUST for f in findings)
    has_any = bool(findings)
    if has_must:
        return 1
    if args.strict and has_any:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
